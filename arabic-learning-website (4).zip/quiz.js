function checkAnswer(button, correct) {
  const result = document.getElementById('result');
  if (correct) {
    result.textContent = 'إجابة صحيحة ✅';
    result.style.color = 'green';
  } else {
    result.textContent = 'إجابة خاطئة ❌';
    result.style.color = 'red';
  }
}
